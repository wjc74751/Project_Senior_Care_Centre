package PatientManagement.servlet;

import PatientManagement.bean.Patient;
import PatientManagement.service.PatientService;
import com.alibaba.fastjson.JSONObject;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
//by 王骏驰
@WebServlet("/patient/update")
public class PatientUpdateServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=utf-8");
        Patient patient = new Patient();
        boolean queryResult = false;
        patient.setId(Integer.parseInt(req.getParameter("id")));
        //set personal info
        patient.setPatientName(req.getParameter("patientName"));
        patient.setAge(Integer.parseInt(req.getParameter("age")));
        patient.setGender(Boolean.parseBoolean(req.getParameter("gender")));
        patient.setContactNumber(Long.parseLong(req.getParameter("contactNumber")));
        patient.setUrgentContactPerson(req.getParameter("urgentContactPerson"));
        patient.setUrgentContactNumber(Long.parseLong(req.getParameter("urgentContactNumber")));
        try {
            queryResult = PatientService.update(patient);
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        String JSONString = JSONObject.toJSONString(queryResult == true ? "修改成功！" : "修改失败！");
        System.out.println(JSONString);
        resp.getWriter().write(JSONString);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一
        doGet(req,resp);
    }

}
//by 王骏驰