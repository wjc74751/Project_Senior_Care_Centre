package PatientManagement.servlet;

import PatientManagement.bean.Patient;
import PatientManagement.service.PatientService;
import com.alibaba.fastjson.JSONObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
//by 王骏驰
@WebServlet("/patient/getAll")
public class PatientGetAllServlet extends HttpServlet { //获取所有的病人信息
    PatientService patientService = new PatientService();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


        resp.setContentType("text/html;charset=utf-8");
        String url = req.getRequestURL().toString();
        String method = req.getMethod();

        List<Patient> patientList=null;



        try {
            patientList = PatientService.getAll();

        } catch (Exception e) {
            e.printStackTrace();
        }

        //将java对象转换为json字符串
        String listJsonStr= JSONObject.toJSONString(patientList);



        resp.getWriter().write(listJsonStr);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一，在doPost里面调用doGEt
        doGet(req, resp);
    }
}
//by 王骏驰