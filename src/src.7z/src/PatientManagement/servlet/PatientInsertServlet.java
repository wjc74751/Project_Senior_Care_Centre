package PatientManagement.servlet;

import PatientManagement.bean.Patient;
import PatientManagement.service.PatientService;
import com.alibaba.fastjson.JSONObject;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Random;
//by 王骏驰
@WebServlet("/patient/insert")
public class PatientInsertServlet extends HttpServlet { //新增病人

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=utf-8");
        Patient patient = new Patient();
        boolean insertResult = false;
        Random random = new Random();
        patient.setId(random.nextInt(2147483647));
        patient.setPatientName(req.getParameter("patientName"));
        patient.setAge(Integer.parseInt(req.getParameter("age")));
        patient.setGender(Boolean.parseBoolean(req.getParameter("gender")));
        patient.setContactNumber(Long.parseLong(req.getParameter("contactNumber")));
        patient.setUrgentContactPerson(req.getParameter("urgentContactPerson"));
        patient.setUrgentContactNumber(Long.parseLong(req.getParameter("urgentContactNumber")));
        patient.setEvaluationNum(0);
        patient.setIsStay(false);
        try {
            insertResult = PatientService.insert(patient);
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        String JSONString = JSONObject.toJSONString(insertResult == true ?"患者创建成功！":"患者创建失败！");
        System.out.println(JSONString);
        resp.getWriter().write(JSONString);


    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一
        doGet(req,resp);
    }


}
//by 王骏驰