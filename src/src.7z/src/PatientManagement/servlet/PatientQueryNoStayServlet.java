package PatientManagement.servlet;

import PatientManagement.bean.Patient;
import PatientManagement.service.PatientService;
import com.alibaba.fastjson.JSONObject;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
//by 王骏驰
@WebServlet("/patient/queryNoStay")
public class PatientQueryNoStayServlet extends HttpServlet { //查询未入住的病人信息

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=utf-8");
        List<Patient> queryResult = null;
        try {
            queryResult = PatientService.queryNoStay();
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        String JSONString = JSONObject.toJSONString(queryResult);
        System.out.println("Query No Stay!");
        resp.getWriter().write(JSONString);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一
        doGet(req,resp);
    }

}
//by 王骏驰