package PatientManagement.bean;
//by 王骏驰
public class Patient{ //  construction of patient
    private int id;
    private String patientName;
    private int age;
    private boolean gender; //male:0,female:1
    private long contactNumber;
    private String urgentContactPerson;
    private long urgentContactNumber;
    private boolean isStay; //未入住：0；入住：1
    private int evaluationNum; //评估次数
    public Patient(){ //empty construction

    }

    public Patient(int id, String patientName, int age, boolean gender, long contactNumber, String urgentContactPerson, long urgentContactNumber,boolean isStay,int evaluationNum) { // construction of Patient
        this.id = id;
        this.patientName = patientName;
        this.age = age;
        this.gender = gender;
        this.contactNumber = contactNumber;
        this.urgentContactPerson = urgentContactPerson;
        this.urgentContactNumber = urgentContactNumber;
        this.isStay = isStay;
        this.evaluationNum = evaluationNum;
    }
    public void setId(int id){this.id = id;}
    public void setPatientName(String patientName){this.patientName = patientName;}
    public void setAge(int age){this.age = age;}
    public void setGender(boolean gender){this.gender = gender;}
    public void setContactNumber(long contactNumber){this.contactNumber = contactNumber;}
    public void setUrgentContactPerson(String urgentContactPerson){this.urgentContactPerson = urgentContactPerson;}
    public void setUrgentContactNumber(long urgentContactNumber){this.urgentContactNumber = urgentContactNumber;}
    public void setIsStay(boolean isStay) {this.isStay = isStay;}
    public void setEvaluationNum(int evaluationNum) {this.evaluationNum = evaluationNum;}

    public int getId(){return id;}
    public String getPatientName(){return patientName;}
    public int getAge(){return age;}
    public boolean getGender(){return gender;}
    public long getContactNumber(){return contactNumber;}
    public String getUrgentContactPerson(){return urgentContactPerson;}
    public long getUrgentContactNumber(){return urgentContactNumber;}
    public boolean getIsStay() {return isStay;}
    public int getEvaluationNum() {return evaluationNum;}

    @Override
    public String toString()
    {
        return ("{id:"+id
                +",patientName:"+patientName
                +",age:"+age
                +",gender:"+gender
                +",contactNumber:"+contactNumber
                +",urgentContactPerson:"+urgentContactPerson
                +",urgentContactNumber:"+urgentContactNumber
                +",isStay:" + isStay
                +",evaluationNum:" + evaluationNum
                +"}"
        );
    }
    // by 王骏驰
    //魈真的好帅，要不是魈谁工作啊？
    //三月七我老婆！
    //测试注释
}