package PatientManagement.dao;

import PatientManagement.bean.Patient;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static PatientManagement.util.DruidUtils.getPool;
//by 王骏驰
public class PatientDao{
    static QueryRunner queryRunner = new QueryRunner(getPool());
    public List<Patient> query(String text) throws SQLException { //全字段模糊查询
        List<Patient> queryResult = new ArrayList<Patient>();
        String sql = "SELECT * FROM patient WHERE ";
        queryResult.addAll(queryRunner.query(sql+"id LIKE "+"'%"+text+"%'",new BeanListHandler<Patient>(Patient.class)));
        queryResult.addAll(queryRunner.query(sql+"patientName LIKE "+"'%"+text+"%'",new BeanListHandler<Patient>(Patient.class)));
        queryResult.addAll(queryRunner.query(sql+"age LIKE "+"'%"+text+"%'",new BeanListHandler<Patient>(Patient.class)));
        queryResult.addAll(queryRunner.query(sql+"gender LIKE "+"'%"+text+"%'",new BeanListHandler<Patient>(Patient.class)));
        queryResult.addAll(queryRunner.query(sql+"contactNumber LIKE "+"'%"+text+"%'",new BeanListHandler<Patient>(Patient.class)));
        queryResult.addAll(queryRunner.query(sql+"urgentContactPerson LIKE "+"'%"+text+"%'",new BeanListHandler<Patient>(Patient.class)));
        queryResult.addAll(queryRunner.query(sql+"urgentContactNumber LIKE "+"'%"+text+"%'",new BeanListHandler<Patient>(Patient.class)));
        queryResult.addAll(queryRunner.query(sql+"isStay LIKE "+"'%"+text+"%'",new BeanListHandler<Patient>(Patient.class)));
        queryResult.addAll(queryRunner.query(sql+"evaluationNum LIKE "+"'%"+text+"%'",new BeanListHandler<Patient>(Patient.class)));
        for (int i = 0;i < queryResult.size();i++)
            for (int j = (i + 1);j < queryResult.size();j++)
                if (queryResult.get(i).getId() == queryResult.get(j).getId())
                {
                    queryResult.remove(j);//去重
                    j--; //去重
                }
        return queryResult;
    }
    static public int insert(Patient patient) throws SQLException //添加
    {
        String sql = "INSERT INTO patient (id,patientName,age,gender,contactNumber,urgentContactPerson,urgentContactNumber,isStay,evaluationNum) VALUES (?,?,?,?,?,?,?,?,?)";
        int insertResult = 0;
        insertResult = queryRunner.update(sql,
                    patient.getId(),
                    patient.getPatientName(),
                    patient.getAge(),
                    patient.getGender(),
                    patient.getContactNumber(),
                    patient.getUrgentContactPerson(),
                    patient.getUrgentContactNumber(),
                    patient.getIsStay(),
                    patient.getEvaluationNum()
                    );
        return insertResult;

    }
    static public int update(Patient patient) throws SQLException //修改
    {
        int updateResult = 0;
        String sql = "UPDATE patient SET patientName=?,age=?,gender=?,contactNumber=?,urgentContactPerson=?,urgentContactNumber=? WHERE id=?";
        updateResult = queryRunner.update(sql,
                patient.getPatientName(),
                patient.getAge(),
                patient.getGender(),
                patient.getContactNumber(),
                patient.getUrgentContactPerson(),
                patient.getUrgentContactNumber(),
                patient.getId()
                );
        return updateResult;
    }
    static public List<Patient> getAll() throws SQLException {

        String sql = "SELECT * FROM patient ";
        //执行查询，将结果集封装成List<Student>
        //
        return queryRunner.query(sql, new BeanListHandler<Patient>(Patient.class));
    }
    static public int delete(int id) throws SQLException { //通过ID进行删除
        int deleteResult = 0;
        String sql = "DELETE FROM patient WHERE id=?";
        deleteResult = queryRunner.update(sql,id);
        return deleteResult;
    }
    static public List<Patient> queryNoStay() throws SQLException //查询没有入住的病人
    {
        String sql = "SELECT id,patientName FROM patient WHERE isStay=0";
        return queryRunner.query(sql,new BeanListHandler<Patient>(Patient.class));
    }
    static public int stayPatient(int id) throws SQLException //设置病人为已入住
    {
        String sql = "UPDATE patient SET isStay=1 WHERE id=?";
        return queryRunner.update(sql,id);
    }
    static public List<Patient> queryById(int id) throws SQLException { //通过ID查询
        String sql = "SELECT * FROM patient WHERE id=?";
        return queryRunner.query(sql,new BeanListHandler<Patient>(Patient.class),id);
    }
    static public int evaluate(int id,int evaluationNum) throws SQLException { //通过ID进行评估
        String sql = "UPDATE patient SET evaluationNum=? WHERE id=?";
        return queryRunner.update(sql,evaluationNum,id);
    }
}
//by 王骏驰
//我要做神里小姐的狗！