package PatientManagement.service;

import BuildManagement.dao.BuildDao;
import PatientManagement.bean.Patient;
import PatientManagement.dao.PatientDao;
import StayManagement.bean.Stay;
import StayManagement.dao.StayDao;

import java.sql.SQLException;
import java.util.List;

//by 王骏驰
public class PatientService{
    static PatientDao patientDao = new PatientDao();

    public static List<Patient> query(String text) throws SQLException //查询
    {
        return patientDao.query(text);
    }
    public static boolean insert(Patient patient) throws SQLException //添加
    {
        if (patient.getPatientName() == null ||
                patient.getAge() < 0 ||
                patient.getAge() > 134 ||
                patient.getUrgentContactPerson() == null
        )
        {
            return false;
        }
        else
        {
            if (PatientDao.insert(patient) == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

    }
    public static boolean update(Patient patient) throws SQLException //true:更新了，false:没有更新
    {
        if (patient.getPatientName() == null ||
                patient.getAge() < 0 ||
                patient.getAge() > 134 ||
                patient.getUrgentContactPerson() == null
        )
        {
            return false;
        }
        else
        {
            if (PatientDao.update(patient) == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
    public static List<Patient> getAll() throws Exception{

        return PatientDao.getAll();
    }
    public static boolean delete(List<Integer> idList) throws SQLException { //批量删除
        int deleteResult = 0;
        for (int i = 0;i < idList.size();i++)
        {
            if (StayDao.queryById(idList.get(i)) != null && !StayDao.queryById(idList.get(i)).isEmpty()) //查询入住情况，有无入住
            {
                Stay stay = StayDao.queryById(idList.get(i)).get(0);
                int bedId = stay.getBedId();
                BuildDao.outStayBed(bedId); //bed out of stay ！
            }
            deleteResult += PatientDao.delete(idList.get(i));

        }
        if (deleteResult == idList.size() && idList.size() != 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public static List<Patient> queryNoStay() throws SQLException //查询未入住的病人信息
    {
        return PatientDao.queryNoStay();
    }
    public static boolean evaluate(int id) throws SQLException //通过ID进行评估
    {
        Patient patient = PatientDao.queryById(id).get(0);
        int previousEvaluationNum = patient.getEvaluationNum();
        int currentEvaluationNum = patient.getEvaluationNum() + 1;
        int evaluationResult = PatientDao.evaluate(id,currentEvaluationNum);
        return (evaluationResult == 1);
    }
}
//by 王骏驰
