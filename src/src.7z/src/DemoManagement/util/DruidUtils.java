package DemoManagement.util;

import com.alibaba.druid.pool.DruidDataSourceFactory;

import javax.sql.DataSource;
import java.util.Properties;

public class DruidUtils {
    private static DataSource dataSource;
    static {

        try {
            Properties properties = new Properties();
            properties.load(DruidUtils.class.getResourceAsStream(("/PatientManagement/druid.properties")));
            dataSource = DruidDataSourceFactory.createDataSource(properties);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    public static DataSource getPool()
    {
        return dataSource;
    }
}
