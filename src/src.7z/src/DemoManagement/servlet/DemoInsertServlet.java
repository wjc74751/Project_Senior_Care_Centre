package DemoManagement.servlet;

import DemoManagement.bean.Demo;
import DemoManagement.service.DemoService;
import com.alibaba.fastjson.JSONObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Random;
//by 戴嘉欣
@WebServlet("/Demo/insert")
public class DemoInsertServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=utf-8");
        Demo demo = new Demo();
        boolean insertResult = false;
        Random random = new Random();
        demo.setDemoId(random.nextInt(2147483647));
        demo.setDemoTitle(req.getParameter("demoTitle"));
        try {
            insertResult = DemoService.insert(demo);
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }

        String JSONString = JSONObject.toJSONString(insertResult ?"成功创建模板！":"创建失败！");
        System.out.println(JSONString);
        resp.getWriter().write(JSONString);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一
        doGet(req,resp);
    }

}
