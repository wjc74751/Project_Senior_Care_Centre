package DemoManagement.servlet;

import DemoManagement.bean.Demo;
import DemoManagement.service.DemoService;
import com.alibaba.fastjson.JSONObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
//by 戴嘉欣
@WebServlet("/Demo/query")
public class DemoQueryServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=utf-8");
        List<Demo> queryResult = null;
        try {
            queryResult = DemoService.query(req.getParameter("queryText"));
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        String JSONString = JSONObject.toJSONString(queryResult);
        System.out.println("Query : "+req.getParameter("queryText"));
        resp.getWriter().write(JSONString);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一
        doGet(req,resp);
    }

}
