package DemoManagement.servlet;


import DemoManagement.bean.Demo;
import DemoManagement.service.DemoService;
import com.alibaba.fastjson.JSONObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
//by 戴嘉欣
@WebServlet("/Demo/getAll")
public class DemoGetAllServlet extends HttpServlet {

   DemoService demoService = new DemoService();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


        resp.setContentType("text/html;charset=utf-8");
        String url = req.getRequestURL().toString();
        String method = req.getMethod();

        List<Demo> demoList=null;



        try {
            demoList = DemoService.getAll();

        } catch (Exception e) {
            e.printStackTrace();
        }

        //将java对象转换为json字符串
        String listJsonStr= JSONObject.toJSONString(demoList);



        resp.getWriter().write(listJsonStr);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一，在doPost里面调用doGEt
        doGet(req, resp);
    }
}
