package DemoManagement.dao;

import DemoManagement.bean.Demo;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


import static DemoManagement.util.DruidUtils.getPool;
//by 戴嘉欣
public class DemoDao {

    static QueryRunner queryRunner = new QueryRunner(getPool());

    public List<Map<String, Object>> getByDemoId(int demoId) throws SQLException {
        String sql = "SELECT questionId,questionContent,selectA,selectB,selectC FROM question WHERE questionId IN \n" +
                "(SELECT questionId FROM dqlinks WHERE demoId=?)";
        return queryRunner.query(sql, new MapListHandler(), demoId);
    }

    public static List<Demo> query(String text) throws SQLException {
        List<Demo> queryResult = new ArrayList<Demo>();
        String sql = "SELECT * FROM Demo WHERE ";
        queryResult.addAll(queryRunner.query(sql + "demoId LIKE " + "'%" + text + "%'", new BeanListHandler<Demo>(Demo.class)));
        queryResult.addAll(queryRunner.query(sql + "demoTitle LIKE " + "'%" + text + "%'", new BeanListHandler<Demo>(Demo.class)));

        for (int i = 0; i < queryResult.size(); i++)
            for (int j = (i + 1); j < queryResult.size(); j++)
                if (queryResult.get(i).getDemoId() == queryResult.get(j).getDemoId()) {
                    queryResult.remove(j);//去重
                    j--; //去重
                }
        System.out.println(queryResult);
        return queryResult;
    }

     static public int insert(Demo demo) throws SQLException {
        String sql = "INSERT INTO demo (demoId,demoTitle) VALUES (?,?)";
        int insertResult = 0;
        insertResult = queryRunner.update(sql,
                demo.getDemoId(),
                demo.getDemoTitle()
        );
        return insertResult;
    }

    static public int delete(int demoId) throws SQLException {
        int deleteResult = 0;
        String sql = "DELETE FROM demo WHERE demoId=?";
        deleteResult = queryRunner.update(sql,demoId);
        getAll();
        return deleteResult;
    }

    static public int update(Demo demo) throws SQLException {
        int updateResult = 0;
        String sql = "UPDATE demo SET demoTitle=? WHERE demoId=?";
        updateResult = queryRunner.update(sql,
                demo.getDemoTitle(),
                demo.getDemoId()
        );
        return updateResult;
    }


    static public List<Demo> getAll() throws SQLException {

        String sql = "SELECT * FROM Demo ";
        //执行查询，将结果集封装成List<Student>
        //
        return queryRunner.query(sql, new BeanListHandler<Demo>(Demo.class));
    }
    static public List<Demo> getById(int demoId) throws SQLException {

        String sql = "SELECT * from Demo WHERE demoId=?";
        //执行查询，将结果集封装成List<Student>
        //
        return queryRunner.query(sql, new BeanListHandler<Demo>(Demo.class),demoId);
    }

}