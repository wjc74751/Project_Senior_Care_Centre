package DemoManagement.service;

import DemoManagement.bean.Demo;
import DemoManagement.dao.DemoDao;

import java.sql.SQLException;
import java.util.List;
//by 戴嘉欣
public class DemoService {

    static DemoDao demoDao = new DemoDao();
    //全字段模糊查询
    public static List<Demo> query(String text) throws SQLException
    {
        return demoDao.query(text);
    }

    //增加
    public static boolean insert(Demo demo) throws SQLException
    {
        if (

                demo.getDemoTitle() == null
        )
        {
            return false;
        }

        return DemoDao.insert(demo) !=0;

    }
    //修改
    public static boolean update(Demo demo) throws SQLException //true:更新了 false:没有更新
    {
        if (
                demo.getDemoTitle() == null
        )
        {
            return false;
        }
        else
        {
            if (DemoDao.update(demo) == 0)
            {
                return false;
            }
            else
            {
                DemoDao.update(demo);
                return true;
            }
        }
    }

    //批量删除模板
    public static boolean delete(List<Integer> idList) throws SQLException {
        int deleteResult = 0;
        for (int i = 0;i < idList.size();i++)
        {
            deleteResult += DemoDao.delete(idList.get(i));
        }
        if (deleteResult == idList.size() && idList.size() != 0)
        {

            return true;
        }
        else
        {

            return false;
        }
    }
    //查询全部Demo
    public static List<Demo> getAll() throws Exception{

        return DemoDao.getAll();
    }
    public static List<Demo> getById(int demoId) throws SQLException {
        return DemoDao.getById(demoId);
    }

}
    



