package DemoManagement.bean;
//by 戴嘉欣
public class Demo {
    //构造
    private int demoId; //关联值
    private String demoTitle;

    public Demo(){ //构造

    }
        public Demo (int demoId, String demoTitle) //构造Demo
        {
        this.demoId = demoId;
        this.demoTitle = demoTitle;
    }

    public int getDemoId() {
        return demoId;
    }

    public void setDemoId(int demoId) {
        this.demoId = demoId;
    }

    public String getDemoTitle() {
        return demoTitle;
    }

    public void setDemoTitle(String demoTitle) {
        this.demoTitle = demoTitle;
    }


    @Override
    public String toString()
    {
        return ("{demoId:"+demoId
                +",demoTitle:"+demoTitle
                +"}"
        );
    }

}
