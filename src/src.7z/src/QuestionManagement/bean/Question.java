package QuestionManagement.bean;
//by 马沛怡
public class Question{
    //构造
    private int questionId;
    private String questionContent;
    private String selectA;
    private String selectB;
    private String selectC;
    private String preferSelect;
    private int demoId; //关联值
    private String demoTitle;
    public Question(){ //空构造

    }

    public Question(int questionId, String questionContent, String selectA, String selectB, String selectC,String preferSelect,int demoId,String demoTitle) { //构造Question
        this.questionId = questionId;
        this.questionContent = questionContent;
        this.selectA = selectA;
        this.selectB = selectB;
        this.selectC = selectC;
        this.preferSelect = preferSelect;
        this.demoId = demoId;
        this.demoTitle = demoTitle;
    }
    public void setQuestionId(int questionId){this.questionId = questionId;}
    public void setQuestionContent(String questionContent){this.questionContent = questionContent;}
    public void setSelectA(String selectA){this.selectA = selectA;}
    public void setSelectB(String selectB){this.selectB = selectB;}
    public void setSelectC(String selectC){this.selectC = selectC;}
    public void setPreferSelect(String preferSelect) {this.preferSelect = preferSelect;}
    public void setDemoId(int demoId) {this.demoId = demoId;}
    public void setDemoTitle(String demoTitle) { this.demoTitle = demoTitle; }

    public int getQuestionId(){return questionId;}
    public String getQuestionContent(){return questionContent;}
    public String getSelectA(){return selectA;}
    public String getSelectB(){return selectB;}
    public String getSelectC(){return selectC;}
    public String getPreferSelect() {return preferSelect;}
    public int getDemoId() {return demoId;}
    public String getDemoTitle() {return demoTitle;}
}