package QuestionManagement.servlet;

import QuestionManagement.bean.Question;
import QuestionManagement.service.QuestionService;
import com.alibaba.fastjson.JSONObject;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;
//by 马沛怡
@WebServlet("/question/getAll")
public class QuestionGetAllServlet extends HttpServlet {

    QuestionService patientService = new QuestionService();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


        resp.setContentType("text/html;charset=utf-8");
        String url = req.getRequestURL().toString();
        String method = req.getMethod();

        List<Question> questionList=null;



        try {
            questionList = QuestionService.getAll();

        } catch (Exception e) {
            e.printStackTrace();
        }

        //将java对象转换为json字符串
        String listJsonStr= JSONObject.toJSONString(questionList);



        resp.getWriter().write(listJsonStr);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一，在doPost里面调用doGEt
        doGet(req, resp);
    }



}
