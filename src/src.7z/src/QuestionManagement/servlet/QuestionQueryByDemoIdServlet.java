package QuestionManagement.servlet;


import DemoManagement.service.DemoService;
import QuestionManagement.bean.Question;
import QuestionManagement.service.QuestionService;
import com.alibaba.fastjson.JSONObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
//by 马沛怡
@WebServlet("/question/queryByDemoId")
public class QuestionQueryByDemoIdServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=utf-8");
        List<Question> queryResult = null;
        try {
            queryResult = QuestionService.getByDemoId(Integer.parseInt(req.getParameter("demoId")));
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }

        String JSONString = JSONObject.toJSONString(queryResult);
        resp.getWriter().write(JSONString);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一
        doGet(req,resp);
    }

}