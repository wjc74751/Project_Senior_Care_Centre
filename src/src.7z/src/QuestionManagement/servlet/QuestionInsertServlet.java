package QuestionManagement.servlet;

import DemoManagement.service.DemoService;
import QuestionManagement.bean.Question;
import QuestionManagement.service.QuestionService;
import com.alibaba.fastjson.JSONObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Random;

@WebServlet("/question/insert")
public class QuestionInsertServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=utf-8");
        Question question = new Question();
        boolean insertResult = false;
        Random random = new Random();
        question.setQuestionId(random.nextInt(2147483647));
        question.setQuestionContent(req.getParameter("questionContent"));
        question.setSelectA(req.getParameter("selectA"));
        question.setSelectB(req.getParameter("selectB"));
        question.setSelectC(req.getParameter("selectC"));
        question.setPreferSelect(req.getParameter("preferSelect"));
        question.setDemoId(Integer.parseInt(req.getParameter("demoId")));

        try {
            insertResult = QuestionService.insert(question);
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        String JSONString = JSONObject.toJSONString(insertResult == true ?"问题创建成功！":"问题创建失败！");
        System.out.println(JSONString);
        resp.getWriter().write(JSONString);


    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一
        doGet(req,resp);
    }


}