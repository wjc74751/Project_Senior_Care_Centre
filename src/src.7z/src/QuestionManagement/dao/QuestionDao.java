package QuestionManagement.dao;

import QuestionManagement.bean.Question;
import PatientManagement.util.DruidUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
//by 马沛怡
public class QuestionDao<queryRunner> {

    static QueryRunner queryRunner = new QueryRunner(DruidUtils.getPool());


//    public List<Map<String,Object>> getByDemoId(int demoId) throws SQLException {
//        String sql = "SELECT questionId,questionContent,selectA,selectB,selectC FROM question WHERE questionId IN" +
//                "(SELECT questionId FROM dqlinks WHERE demoId=?)";
//        return queryRunner.query(sql,new MapListHandler(),demoId);
//
//    }


    public List<Question> query(String text) throws SQLException {
        List<Question> queryResult = new ArrayList<Question>();
        String sql = "SELECT * FROM Question WHERE ";
        queryResult.addAll(queryRunner.query(sql+"questionId LIKE "+"'%"+text+"%'",new BeanListHandler<Question>(Question.class)));
        queryResult.addAll(queryRunner.query(sql+"questionContent LIKE "+"'%"+text+"%'",new BeanListHandler<Question>(Question.class)));
        queryResult.addAll(queryRunner.query(sql+"selectA LIKE "+"'%"+text+"%'",new BeanListHandler<Question>(Question.class)));
        queryResult.addAll(queryRunner.query(sql+"selectB LIKE "+"'%"+text+"%'",new BeanListHandler<Question>(Question.class)));
        queryResult.addAll(queryRunner.query(sql+"selectC LIKE "+"'%"+text+"%'",new BeanListHandler<Question>(Question.class)));
        queryResult.addAll(queryRunner.query(sql+"preferSelect LIKE "+"'%"+text+"%'",new BeanListHandler<Question>(Question.class)));
        queryResult.addAll(queryRunner.query(sql+"demoId LIKE "+"'%"+text+"%'",new BeanListHandler<Question>(Question.class)));
        for (int i = 0;i < queryResult.size();i++)
            for (int j = (i + 1);j < queryResult.size();j++)
                if (queryResult.get(i).getQuestionId() == queryResult.get(j).getQuestionId())
                {
                    queryResult.remove(j);//去重
                    j--; //去重
                }
        return queryResult;
    }

    static public int insert(Question question) throws SQLException
    {
        String sql = "INSERT INTO Question (questionId,questionContent,selectA,selectB,selectC,preferSelect,demoId) VALUES (?,?,?,?,?,?,?)";
        int insertResult = 0;
        insertResult = queryRunner.update(sql,
                question.getQuestionId(),
                question.getQuestionContent(),
                question.getSelectA(),
                question.getSelectB(),
                question.getSelectC(),
                question.getPreferSelect(),
                question.getDemoId()
        );
        return insertResult;

    }
    static public int update(Question question) throws SQLException
    {
        int updateResult = 0;
        String sql = "UPDATE question SET questionContent=?,selectA=?,selectB=?,selectC=?,preferSelect=?,demoId=? WHERE questionId=?";
        updateResult = queryRunner.update(sql,
                question.getQuestionContent(),
                question.getSelectA(),
                question.getSelectB(),
                question.getSelectC(),
                question.getPreferSelect(),
                question.getDemoId(),
                question.getQuestionId()

        );
        return updateResult;
    }
    static public int delete(int id) throws SQLException {
        int deleteResult = 0;
        String sql = "DELETE FROM question WHERE questionId=?";
        deleteResult = queryRunner.update(sql,id);
        getAll();
        return deleteResult;
    }

    static public List<Question> getAll() throws SQLException {

        String sql = "SELECT * FROM question ";
        //执行查询，将结果集封装成List<Question>
        //
        return queryRunner.query(sql, new BeanListHandler<Question>(Question.class));
    }
    static public List<Question> getByDemoId(int demoId) throws SQLException
    {
        String sql = "SELECT * FROM question WHERE demoId=?";
        return queryRunner.query(sql,new BeanListHandler<Question>(Question.class),demoId);
    }

}
