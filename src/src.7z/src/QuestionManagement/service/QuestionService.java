package QuestionManagement.service;

import QuestionManagement.bean.Question;
import QuestionManagement.dao.QuestionDao;

import java.sql.SQLException;
import java.util.List;
//by 马沛怡
public class QuestionService {

    static QuestionDao questionDao = new QuestionDao();

    public static List<Question> query(String text) throws SQLException //全字段模糊查询
    {
        return questionDao.query(text);
    }
    //增加
    public static boolean insert(Question question) throws SQLException
    {
        if (question.getQuestionContent() == null ||
                question.getSelectA() == null ||
                question.getSelectB() == null ||
                question.getSelectC() == null ||
                question.getPreferSelect() == null
        )
        {
            return false;
        }
        else
        {
            if (QuestionDao.insert(question) == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

    }
    //修改
    public static boolean update(Question question) throws SQLException //true:更新了 false:没有更新
    {
        if (question.getQuestionContent() == null ||
                question.getSelectA() == null ||
                question.getSelectB() == null ||
                question.getSelectC() == null
        )
        {
            return false;
        }
        else
        {
            if (QuestionDao.update(question) == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }


    public static boolean delete(List<Integer> idList) throws SQLException {  //批量删除
        int deleteResult = 0;
        for (int i = 0;i < idList.size();i++)
        {
            deleteResult += QuestionDao.delete(idList.get(i));

        }
        if (deleteResult == idList.size() && idList.size() != 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public static List<Question> getByDemoId(int demoId) throws SQLException  //get by demo id
    {
        return QuestionDao.getByDemoId(demoId);
    }

    //查询全部Question
    public static List<Question> getAll() throws Exception{

        return QuestionDao.getAll();
    }


}
