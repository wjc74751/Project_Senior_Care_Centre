package StaffManagement.service;

import StaffManagement.bean.Doctor;
import StaffManagement.bean.Manager;
import StaffManagement.bean.Nurse;
import StaffManagement.dao.DoctorDao;
import StaffManagement.dao.ManagerDao;
import StaffManagement.dao.NurseDao;

import java.sql.SQLException;
//by 王骏驰
public class LoginService {
    public static int Login(String login, String password, int userType) throws SQLException { //用账号密码进行登录
        // 1：医生  2:护士   3：管理员
        if (userType == 1) {
            if (DoctorDao.getByDoctorLogin(login) != null && !DoctorDao.getByDoctorLogin(login).isEmpty())
            {
                Doctor doctor = DoctorDao.getByDoctorLogin(login).get(0);
                if (password.equals(doctor.getDoctorPassword())) {
                    return 1;
                } else {
                    return 0; //登录失败
                }
            }

        }
        else if (userType == 3){
            if (ManagerDao.getByManagerLogin(login) != null && !ManagerDao.getByManagerLogin(login).isEmpty())
            {
                Manager manager = ManagerDao.getByManagerLogin(login).get(0);
                if (password.equals(manager.getManagerPassword())){
                    return 3;
                } else {
                    return 0;//登陆失败
                }
            }

        }
        else if (userType == 2){
            if (NurseDao.getByNurseLogin(login) != null && !NurseDao.getByNurseLogin(login).isEmpty())
            {
                Nurse nurse = NurseDao.getByNurseLogin(login).get(0);
                if (password.equals(nurse.getNursePassword())){
                    return 2;
                }else {
                    return 0; //登陆失败
                }
            }


        }
        return 0;//登陆失败
    }

}





