package StaffManagement.service;

import StaffManagement.bean.Nurse;
import StaffManagement.dao.NurseDao;

import java.sql.SQLException;
import java.util.List;
//by 戴嘉欣
public class NurseService {
    static NurseDao nurseDao = new NurseDao();

    public static List<Nurse> query(String text) throws SQLException //全字段查询Nurse
    {
        return nurseDao.query(text);
    }


    public static boolean insert(Nurse nurse) throws SQLException //新增
    {
        if (nurse.getNurseName() == null ||
                nurse.getNurseTitle() == null
        )
        {
            return false;
        }
        return NurseDao.insert(nurse) !=0;


    }

    public static boolean update(Nurse nurse) throws SQLException //更新，true:更新了 false:没有更新
    {
        if (nurse.getNurseName() == null ||
                nurse.getNurseTitle() == null
        )
        {
            return false;
        }
        else
        {
            if (NurseDao.update(nurse) == 0)
            {
                return false;
            }
            else
            {
                NurseDao.update(nurse);
                return true;
            }
        }
    }

    public static boolean delete(List<Integer> idList) throws SQLException { //批量删除
        int deleteResult = 0;
        for (int i = 0;i < idList.size();i++)
        {
            deleteResult = NurseDao.delete(idList.get(i));

        }
        deleteResult = idList.size();
        if ( idList.size() > 0)
        {
            return true;
        }
        else
        {
            return false;
        }

    }

    public static List<Nurse> getAll() throws Exception{

        return NurseDao.getAll();
    }


}
