package StaffManagement.service;

import StaffManagement.bean.Doctor;
import StaffManagement.dao.DoctorDao;

import java.sql.SQLException;
import java.util.List;
//by 戴嘉欣
public class DoctorService {
    static DoctorDao doctorDao = new DoctorDao();

    public static List<Doctor> query(String text) throws SQLException //全字段模糊查询
    {
        return doctorDao.query(text);
    }


    public static boolean insert(Doctor doctor) throws SQLException //新增
    {
        if (doctor.getDoctorName() == null ||
                doctor.getDoctorTitle() == null
        )
        {
            return false;
        }
        else
        {
            DoctorDao.insert(doctor);
            return true;

        }

    }
    public static boolean update(Doctor doctor) throws SQLException //修改，true:更新了 false:没有更新
    {
        if (doctor.getDoctorName() == null ||
                doctor.getDoctorTitle() == null
        )
        {
            return false;
        }
        else
        {
            if (DoctorDao.update(doctor) == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
    public static boolean delete(List<Integer> idList) throws SQLException { //批量删除医生
        int deleteResult = 0;
        for (int i = 0;i < idList.size();i++)
        {
            deleteResult = DoctorDao.delete(idList.get(i));

        }
        deleteResult = idList.size();
        if ( idList.size() > 0)
        {

            return true;
        }
        else
        {

            return false;
        }
    }

    public static List<Doctor> getAll() throws Exception{ //查询全部的医生

        return DoctorDao.getAll();
    }


}
