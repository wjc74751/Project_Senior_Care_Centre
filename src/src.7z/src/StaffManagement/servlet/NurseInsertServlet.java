package StaffManagement.servlet;

import StaffManagement.bean.Nurse;
import StaffManagement.service.NurseService;
import com.alibaba.fastjson.JSONObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.Random;
//by 戴嘉欣
@WebServlet("/Nurse/insert")
public class NurseInsertServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=utf-8");
        Nurse nurse = new Nurse();
        boolean insertResult = false;
        Random random = new Random();
        nurse.setNurseId(random.nextInt(2147483647));
        nurse.setNurseLogin(req.getParameter("nurseLogin"));
        nurse.setNursePassword(req.getParameter("nursePassword"));
        nurse.setNurseName(req.getParameter("nurseName"));
        nurse.setNurseTitle(req.getParameter("nurseTitle"));
        nurse.setNurseSpeciality(req.getParameter("nurseSpeciality"));
        nurse.setNurseBirthDate(Date.valueOf(req.getParameter("nurseBirthDate")));
        nurse.setNurseTel(Long.parseLong(req.getParameter("nurseTel")));



        try {
            insertResult = NurseService.insert(nurse);
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        String JSONString = JSONObject.toJSONString(insertResult == true ?"成功创建护士！":"创建失败！");
        System.out.println(JSONString);
        resp.getWriter().write(JSONString);


    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一
        doGet(req,resp);
    }

}
