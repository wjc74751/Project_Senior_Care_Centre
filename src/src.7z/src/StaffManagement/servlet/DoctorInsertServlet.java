package StaffManagement.servlet;

import StaffManagement.bean.Doctor;
import StaffManagement.service.DoctorService;
import com.alibaba.fastjson.JSONObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.Random;
//by 戴嘉欣
@WebServlet("/Doctor/insert")
public class DoctorInsertServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=utf-8");
        Doctor doctor = new Doctor();
        boolean insertResult = false;
        Random random = new Random();

        doctor.setDoctorId(random.nextInt(2147483647));
        doctor.setDoctorLogin(req.getParameter("doctorLogin"));
        doctor.setDoctorPassword(req.getParameter("doctorPassword"));
        doctor.setDoctorName(req.getParameter("doctorName"));
        doctor.setDoctorTitle(req.getParameter("doctorTitle"));
        doctor.setDoctorSpeciality(req.getParameter("doctorSpeciality"));
        doctor.setDoctorBirthDate(Date.valueOf(req.getParameter("doctorBirthDate")));
        doctor.setDoctorTel((req.getParameter("doctorTel")));

        try {
            insertResult = DoctorService.insert(doctor);
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }

        String JSONString = JSONObject.toJSONString(insertResult ?"成功创建医生！":"创建失败！");
        System.out.println(JSONString);
        resp.getWriter().write(JSONString);


    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一
        doGet(req,resp);
    }

}
