package StaffManagement.servlet;

import StaffManagement.bean.Doctor;
import StaffManagement.service.DoctorService;
import com.alibaba.fastjson.JSONObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
//by 戴嘉欣
@WebServlet("/Doctor/update")
public class DoctorUpdateServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=utf-8");
        Doctor doctor = new Doctor();
        boolean queryResult = false;
        doctor.setDoctorId(Integer.parseInt(req.getParameter("doctorId")));
        //set personal info
        doctor.setDoctorName(req.getParameter("doctorName"));
        doctor.setDoctorLogin(req.getParameter("doctorLogin"));
        doctor.setDoctorPassword(req.getParameter("doctorPassword"));
        doctor.setDoctorTitle((req.getParameter("doctorTitle")));
        doctor.setDoctorSpeciality(req.getParameter("doctorSpeciality"));
        doctor.setDoctorBirthDate(Date.valueOf(req.getParameter("doctorBirthDate")));
        doctor.setDoctorTel(req.getParameter("doctorTel"));
        try {
            queryResult = DoctorService.update(doctor);
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        String JSONString = JSONObject.toJSONString(queryResult == true ? "修改成功！" : "修改失败！");
        System.out.println(JSONString);
        resp.getWriter().write(JSONString);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一
        doGet(req,resp);
    }

}
