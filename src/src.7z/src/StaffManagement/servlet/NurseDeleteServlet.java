package StaffManagement.servlet;

import StaffManagement.service.NurseService;
import com.alibaba.fastjson.JSONObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
//by 戴嘉欣
@WebServlet("/Nurse/delete")
public class NurseDeleteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=utf-8");
        boolean deleteResult = false;

        int num = Integer.parseInt(req.getParameter("num"));
        List<Integer> idList = new ArrayList<Integer>();
        if (!req.getParameter("id1").equals("undefined"))
        {
            idList.add(Integer.parseInt(req.getParameter("id1")));
        }
        if (!req.getParameter("id2").equals("undefined"))
        {
            idList.add(Integer.parseInt(req.getParameter("id2")));
        }
        if (!req.getParameter("id3").equals("undefined"))
        {
            idList.add(Integer.parseInt(req.getParameter("id3")));
        }
        if (!req.getParameter("id4").equals("undefined"))
        {
            idList.add(Integer.parseInt(req.getParameter("id4")));
        }
        if (!req.getParameter("id5").equals("undefined"))
        {
            idList.add(Integer.parseInt(req.getParameter("id5")));
        }
        System.out.println(idList);
        try {
            deleteResult = NurseService.delete(idList);

        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        String JSONString = JSONObject.toJSONString(deleteResult ?"患者删除成功！":"患者删除失败！");
        System.out.println(JSONString);
        resp.getWriter().write(JSONString);
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一，在doPost里面调用doGEt
        doGet(req, resp);
    }

}
