package StaffManagement.servlet;

import StaffManagement.bean.Nurse;
import StaffManagement.service.NurseService;
import com.alibaba.fastjson.JSONObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
//by 戴嘉欣
@WebServlet("/Nurse/update")
public class NurseUpdateServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=utf-8");
        Nurse nurse = new Nurse();
        boolean queryResult = false;
        nurse.setNurseId(Integer.parseInt(req.getParameter("nurseId")));
        //set personal info
        nurse.setNurseName(req.getParameter("nurseName"));
        nurse.setNurseLogin(req.getParameter("nurseLogin"));
        nurse.setNursePassword(req.getParameter("nursePassword"));
        nurse.setNurseTitle((req.getParameter("nurseTitle")));
        nurse.setNurseSpeciality(req.getParameter("nurseSpeciality"));
        nurse.setNurseBirthDate(Date.valueOf(req.getParameter("nurseBirthDate")));
        nurse.setNurseTel(Long.parseLong(req.getParameter("nurseTel")));
        try {
            queryResult = NurseService.update(nurse);
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        String JSONString = JSONObject.toJSONString(queryResult ? "修改成功！" : "修改失败！");
        System.out.println(JSONString);
        resp.getWriter().write(JSONString);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一
        doGet(req,resp);
    }

}
