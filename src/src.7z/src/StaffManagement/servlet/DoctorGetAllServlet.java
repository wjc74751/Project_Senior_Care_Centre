package StaffManagement.servlet;


import StaffManagement.bean.Doctor;
import StaffManagement.service.DoctorService;
import com.alibaba.fastjson.JSONObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
//by 戴嘉欣
@WebServlet("/Doctor/getAll")
public class DoctorGetAllServlet extends HttpServlet {

    DoctorService doctorService = new DoctorService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


        resp.setContentType("text/html;charset=utf-8");
        String url = req.getRequestURL().toString();
        String method = req.getMethod();

        List<Doctor> doctorList = null;


        try {
            doctorList = DoctorService.getAll();

        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(doctorList);
        //将java对象转换为json字符串
        String listJsonStr = JSONObject.toJSONString(doctorList);


        resp.getWriter().write(listJsonStr);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一，在doPost里面调用doGEt
        doGet(req, resp);

    }
}