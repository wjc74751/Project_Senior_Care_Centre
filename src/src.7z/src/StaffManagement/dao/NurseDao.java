package StaffManagement.dao;

import StaffManagement.bean.Nurse;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static StaffManagement.util.DruidUtils.getPool;
//by 戴嘉欣
public class NurseDao {
    static QueryRunner queryRunner = new QueryRunner(getPool());
    public List<Nurse> query(String text) throws SQLException {
        List<Nurse> queryResult = new ArrayList<Nurse>();
        String sql = "SELECT * FROM Nurse WHERE ";
        queryResult.addAll(queryRunner.query(sql+"nurseId LIKE "+"'%"+text+"%'",new BeanListHandler<Nurse>(Nurse.class)));
        queryResult.addAll(queryRunner.query(sql+"nurseLogin LIKE "+"'%"+text+"%'",new BeanListHandler<Nurse>(Nurse.class)));
        queryResult.addAll(queryRunner.query(sql+"nursePassword LIKE "+"'%"+text+"%'",new BeanListHandler<Nurse>(Nurse.class)));
        queryResult.addAll(queryRunner.query(sql+"nurseName LIKE "+"'%"+text+"%'",new BeanListHandler<Nurse>(Nurse.class)));
        queryResult.addAll(queryRunner.query(sql+"nurseTitle LIKE "+"'%"+text+"%'",new BeanListHandler<Nurse>(Nurse.class)));
        queryResult.addAll(queryRunner.query(sql+"nurseSpeciality LIKE "+"'%"+text+"%'",new BeanListHandler<Nurse>(Nurse.class)));
        queryResult.addAll(queryRunner.query(sql+"nurseBirthDate LIKE "+"'%"+text+"%'",new BeanListHandler<Nurse>(Nurse.class)));
        queryResult.addAll(queryRunner.query(sql+"nurseTel LIKE "+"'%"+text+"%'",new BeanListHandler<Nurse>(Nurse.class)));
        for (int i = 0;i < queryResult.size();i++)
            for (int j = (i + 1);j < queryResult.size();j++)
                if (queryResult.get(i).getNurseId() == queryResult.get(j).getNurseId())
                {
                    queryResult.remove(j);//去重
                    j--; //去重
                }
        System.out.println(queryResult);
        return queryResult;
    }
    static public int insert(Nurse nurse) throws SQLException
    {
        String sql = "INSERT INTO nurse (nurseId,nurseLogin,nursePassword,nurseName,nurseTitle,nurseSpeciality,nurseBirthDate,nurseTel) VALUES (?,?,?,?,?,?,?,?)";
        int insertResult = 0;
        insertResult += queryRunner.update(sql,
                nurse.getNurseId(),
                nurse.getNurseLogin(),
                nurse.getNursePassword(),
                nurse.getNurseName(),
                nurse.getNurseTitle(),
                nurse.getNurseSpeciality(),
                nurse.getNurseBirthDate(),
                nurse.getNurseTel()
        );
        return insertResult;
    }
    static public int delete(int nurseId) throws SQLException {
        int deleteResult = 0;
        String sql = "DELETE FROM nurse WHERE nurseId=?";
        deleteResult = queryRunner.update(sql,nurseId);
        return deleteResult;
    }

    static public int update (Nurse nurse) throws SQLException
    {
        int updateResult = 0;
        String sql = "UPDATE nurse SET nurseLogin=?, nursePassword=?, nurseName=?, nurseTitle=?, nurseSpeciality=?, nurseBirthDate=?, nurseTel=?  WHERE nurseId=?";
        updateResult = queryRunner.update(sql,
                nurse.getNurseLogin(),
                nurse.getNursePassword(),
                nurse.getNurseName(),
                nurse.getNurseTitle(),
                nurse.getNurseSpeciality(),
                nurse.getNurseBirthDate(),
                nurse.getNurseTel(),
                nurse.getNurseId()
        );
        return updateResult;
    }

    static public List<Nurse> getAll() throws SQLException {

        String sql = "SELECT nurseId,nurseLogin,nursePassword,nurseName,nurseTitle,nurseSpeciality,nurseBirthDate,nurseTel FROM nurse ";
        //执行查询，将结果集封装成List<Student>
        //
        return queryRunner.query(sql, new BeanListHandler<Nurse>(Nurse.class));
    }
    static public List<Nurse> getByNurseLogin(String nurseLogin) throws SQLException {
        String sql = " SELECT * FROM nurse WHERE nurseLogin=? ";

        return queryRunner.query(sql,new BeanListHandler<Nurse>(Nurse.class),nurseLogin);
    }

}
