package StaffManagement.dao;

import StaffManagement.bean.Manager;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.List;

import static StaffManagement.util.DruidUtils.getPool;
//by 戴嘉欣
public class ManagerDao {

    static QueryRunner queryRunner = new QueryRunner(getPool());

    static public List<Manager> getByManagerLogin(String managerLogin) throws SQLException {
        String sql = " SELECT * FROM manager WHERE managerLogin=? ";

        return queryRunner.query(sql,new BeanListHandler<Manager>(Manager.class),managerLogin);
    }
}
