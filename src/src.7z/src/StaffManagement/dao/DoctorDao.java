package StaffManagement.dao;

import StaffManagement.bean.Doctor;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static StaffManagement.util.DruidUtils.getPool;

//by 戴嘉欣
public class DoctorDao {
    static QueryRunner queryRunner = new QueryRunner(getPool());

    public List<Doctor> query(String text) throws SQLException {
        List<Doctor> queryResult = new ArrayList<Doctor>();
        String sql = "SELECT * FROM Doctor WHERE ";
        queryResult.addAll(queryRunner.query(sql+"doctorId LIKE "+"'%"+text+"%'",new BeanListHandler<Doctor>(Doctor.class)));
        queryResult.addAll(queryRunner.query(sql+"doctorLogin LIKE "+"'%"+text+"%'",new BeanListHandler<Doctor>(Doctor.class)));
        queryResult.addAll(queryRunner.query(sql+"doctorPassword LIKE "+"'%"+text+"%'",new BeanListHandler<Doctor>(Doctor.class)));
        queryResult.addAll(queryRunner.query(sql+"doctorName LIKE "+"'%"+text+"%'",new BeanListHandler<Doctor>(Doctor.class)));
        queryResult.addAll(queryRunner.query(sql+"doctorTitle LIKE "+"'%"+text+"%'",new BeanListHandler<Doctor>(Doctor.class)));
        queryResult.addAll(queryRunner.query(sql+"doctorSpeciality LIKE "+"'%"+text+"%'",new BeanListHandler<Doctor>(Doctor.class)));
        queryResult.addAll(queryRunner.query(sql+"doctorBirthDate LIKE "+"'%"+text+"%'",new BeanListHandler<Doctor>(Doctor.class)));
        queryResult.addAll(queryRunner.query(sql+"doctorTel LIKE "+"'%"+text+"%'",new BeanListHandler<Doctor>(Doctor.class)));
        for (int i = 0;i < queryResult.size();i++)
            for (int j = (i + 1);j < queryResult.size();j++)
                if (queryResult.get(i).getDoctorId() == queryResult.get(j).getDoctorId())
                {
                    queryResult.remove(j);//去重
                    j--; //去重
                }
        System.out.println(queryResult);
        return queryResult;
    }
    static public int insert(Doctor doctor) throws SQLException
    {
        String sql = "INSERT INTO Doctor (doctorId,doctorLogin,doctorPassword,doctorName,doctorTitle,doctorSpeciality,doctorBirthDate,doctorTel) VALUES (?,?,?,?,?,?,?,?)";
        int insertResult = 0;
        insertResult = queryRunner.update(sql,
                doctor.getDoctorId(),
                doctor.getDoctorLogin(),
                doctor.getDoctorPassword(),
                doctor.getDoctorName(),
                doctor.getDoctorTitle(),
                doctor.getDoctorSpeciality(),
                doctor.getDoctorBirthDate(),
                doctor.getDoctorTel()
                );
        return insertResult;
    }
    static public int delete(int doctorId) throws SQLException {
        int deleteResult = 0;
        String sql = "DELETE FROM doctor WHERE doctorId=?";
        deleteResult = queryRunner.update(sql,doctorId);
        return deleteResult;
    }

    static public int update (Doctor doctor) throws SQLException
    {
        int updateResult = 0;
        String sql = "UPDATE doctor SET doctorLogin=?, doctorPassword=?, doctorName=?, doctorTitle=?, doctorSpeciality=?, doctorBirthDate=?, doctorTel=?  WHERE doctorId=?";
        updateResult = queryRunner.update(sql,
                doctor.getDoctorLogin(),
                doctor.getDoctorPassword(),
                doctor.getDoctorName(),
                doctor.getDoctorTitle(),
                doctor.getDoctorSpeciality(),
                doctor.getDoctorBirthDate(),
                doctor.getDoctorTel(),
                doctor.getDoctorId()
                );
        return updateResult;
    }
    static public List<Doctor> getAll() throws SQLException {

        String sql = "SELECT doctorId,doctorLogin,doctorPassword,doctorName,doctorTitle,doctorSpeciality,doctorBirthDate,doctorTel FROM doctor";
        //执行查询，将结果集封装成List<Student>
        //
        return queryRunner.query(sql, new BeanListHandler<Doctor>(Doctor.class));
    }

    static public List<Doctor> getByDoctorLogin(String doctorLogin) throws SQLException {
        String sql = " SELECT * FROM doctor WHERE doctorLogin=? ";

        return queryRunner.query(sql,new BeanListHandler<Doctor>(Doctor.class),doctorLogin);
    }
}

