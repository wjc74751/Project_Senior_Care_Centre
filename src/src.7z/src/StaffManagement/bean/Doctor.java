package StaffManagement.bean;

import java.sql.Date;
//by 戴嘉欣
public class Doctor {
    //构造
    private String doctorLogin; //登录名
    private String doctorPassword; //密码
    private int doctorId;
    private String doctorName;
    private String doctorTitle;
    private String doctorSpeciality;
    private Date doctorBirthDate;
    private String doctorTel;
    public Doctor(){ //空构造

    }

    public Doctor(String doctorLogin, String doctorPassword, int doctorId, String doctorName, String doctorTitle, String doctorSpeciality, Date doctorBirthDate, String doctorTel) { //构造Doctor
        this.doctorLogin = doctorLogin;
        this.doctorPassword = doctorPassword;
        this.doctorId = doctorId;
        this.doctorName = doctorName;
        this.doctorTitle = doctorTitle;
        this.doctorSpeciality = doctorSpeciality;
        this.doctorBirthDate = doctorBirthDate;
        this.doctorTel = doctorTel;
    }
    public void setDoctorLogin(String doctorLogin){this.doctorLogin = doctorLogin;}
    public void setDoctorPassword(String doctorPassword){this.doctorPassword = doctorPassword;}
    public void setDoctorId(int doctorId){this.doctorId = doctorId;}
    public void setDoctorName(String doctorName){this.doctorName = doctorName;}
    public void setDoctorTitle(String doctorTitle){this.doctorTitle = doctorTitle;}
    public void setDoctorSpeciality(String doctorSpeciality){this.doctorSpeciality = doctorSpeciality;}
    public void setDoctorBirthDate(Date doctorBirthDate){this.doctorBirthDate = doctorBirthDate;}
    public void setDoctorTel(String doctorTel){this.doctorTel = doctorTel;}

    public String getDoctorLogin(){return doctorLogin;}
    public String getDoctorPassword(){return doctorPassword;}
    public int getDoctorId(){return doctorId;}
    public String getDoctorName(){return doctorName;}
    public String getDoctorTitle(){return doctorTitle;}
    public String getDoctorSpeciality(){return doctorSpeciality;}
    public Date getDoctorBirthDate(){return doctorBirthDate;}
    public String getDoctorTel(){return doctorTel;}

    @Override
    public String toString()
    {
        return ("{doctorLogin:"+doctorLogin
                +",doctorPassword:"+doctorPassword
                +",doctorId:"+doctorId
                +",doctorName:"+doctorName
                +",doctorTitle:"+ doctorTitle
                +",doctorSpeciality:"+ doctorSpeciality
                +",doctorBirthDate:"+ doctorBirthDate
                +",doctorTel:"+doctorTel
                +"}"
        );
    }


}
