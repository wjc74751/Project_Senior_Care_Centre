package StaffManagement.bean;

import java.sql.Date;
//by 戴嘉欣
public class Nurse {
    //构造
    private String nurseLogin; //登录名
    private String nursePassword; //密码
    private long nurseId;
    private String nurseName;
    private String nurseTitle;
    private String nurseSpeciality;
    private Date nurseBirthDate;
    private long nurseTel;
    public Nurse(){ //空构造

    }

    public Nurse(String nurseLogin, String nursePassword, long nurseId, String nurseName, String nurseTitle, String nurseSpeciality, Date nurseBirthDate, long nurseTel) { //构造Nurse
        this.nurseLogin = nurseLogin;
        this.nursePassword = nursePassword;
        this.nurseId = nurseId;
        this.nurseName = nurseName;
        this.nurseTitle = nurseTitle;
        this.nurseSpeciality = nurseSpeciality;
        this.nurseBirthDate = nurseBirthDate;
        this.nurseTel = nurseTel;
    }

    public void setNurseLogin(String nurseLogin){this.nurseLogin = nurseLogin;}
    public void setNursePassword(String nursePassword){this.nursePassword = nursePassword;}
    public void setNurseId(long nurseId){this.nurseId = nurseId;}
    public void setNurseName(String nurseName){this.nurseName = nurseName;}
    public void setNurseTitle(String nurseTitle){this.nurseTitle = nurseTitle;}
    public void setNurseSpeciality(String nurseSpeciality){this.nurseSpeciality = nurseSpeciality;}
    public void setNurseBirthDate(Date nurseBirthDate){this.nurseBirthDate = nurseBirthDate;}
    public void setNurseTel(long nurseTel){this.nurseTel = nurseTel;}

    public String getNurseLogin(){return nurseLogin;}
    public String getNursePassword(){return nursePassword;}
    public long getNurseId(){return nurseId;}
    public String getNurseName(){return nurseName;}
    public String getNurseTitle(){return nurseTitle;}
    public String getNurseSpeciality(){return nurseSpeciality;}
    public Date getNurseBirthDate(){return nurseBirthDate;}
    public long getNurseTel(){return nurseTel;}

    @Override
    public String toString()
    {
        return ("{nurseLogin:"+nurseLogin
                +",nursePassword:"+nursePassword
                +",nurseId:"+nurseId
                +",nurseName:"+nurseName
                +",nurseTitle:"+ nurseTitle
                +",nurseSpeciality:"+ nurseSpeciality
                +",nurseBirthDate:"+ nurseBirthDate
                +",nurseTel:"+nurseTel
                +"}"
        );
    }

}
