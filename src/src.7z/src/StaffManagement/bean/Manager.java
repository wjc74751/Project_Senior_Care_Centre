package StaffManagement.bean;
//by 戴嘉欣
public class Manager {
    private String managerLogin;



    private String managerPassword;

    public Manager(){ //空构造

    }

    public Manager(String managerLogin, String managerPassword) //构造Manager
    {
        this.managerLogin = managerLogin;
        this.managerPassword = managerPassword;
    }

    public String getManagerLogin() {
        return managerLogin;
    }

    public void setManagerLogin(String managerLogin) {
        this.managerLogin = managerLogin;
    }

    public String getManagerPassword() {
        return managerPassword;
    }

    public void setManagerPassword(String managerPassword) {
        this.managerPassword = managerPassword;
    }

}

