package StayManagement.service;

import BuildManagement.dao.BuildDao;
import StayManagement.bean.Stay;
import StayManagement.dao.StayDao;
import PatientManagement.bean.Patient;
import PatientManagement.dao.PatientDao;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
//by 王骏驰
public class StayService {
    public static List<Stay> queryByName(String build, String floor, String room, String bed) throws SQLException //通过build，floor，room，bed名称进行查询
    {
        return StayDao.queryByName(build,floor,room,bed);
    }
    public static boolean exchange(int id1,int id2) throws SQLException { //交换床位
        int exchangeResult = 0;
        Stay stay1 = StayDao.queryById(id1).get(0);
        Stay stay2 = StayDao.queryById(id2).get(0);
        exchangeResult += StayDao.exchangeUpdate(id1, stay2.getBedId(), stay2.getBuild(), stay2.getFloor(), stay2.getRoom(), stay2.getBed());
        exchangeResult += StayDao.exchangeUpdate(id2, stay1.getBedId(), stay1.getBuild(), stay1.getFloor(), stay1.getRoom(), stay1.getBed());
        return (exchangeResult == 2);
    }
    public static boolean deleteById(int id) throws SQLException { //通过ID删除入住信息
        Stay stay = StayDao.queryById(id).get(0);
        int bedId = stay.getBedId();
        BuildDao.outStayBed(bedId);
        int deleteResult = PatientDao.delete(id);
        if (deleteResult == 1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public static boolean stay(int id, Date startDate, Date endDate) throws SQLException { //为病人办理入住
        int insertResult = 0;
        if (BuildDao.getNoStayBedId() != null && !BuildDao.getNoStayBedId().isEmpty()) { //判断有无空床位
            int noStayBedId = BuildDao.getNoStayBedId().get(0).getBedId(); //get the first empty bed
            BuildDao.stayBed(noStayBedId); // set bed isStay = 1
            PatientDao.stayPatient(id);
            Patient patient = PatientDao.queryById(id).get(0);
            String patientName = patient.getPatientName();
            int age = patient.getAge();
            boolean gender = patient.getGender();
            String bed = BuildDao.getBedByBedId(noStayBedId).get(0).getBuildStructureName();
            String room = BuildDao.getByName(bed).get(0).getParent();
            String floor = BuildDao.getByName(room).get(0).getParent();
            String build = BuildDao.getByName(floor).get(0).getParent();
            insertResult = StayDao.insert(id, patientName, age, gender, noStayBedId, build, floor, room, bed, startDate, endDate);
        }

        return (insertResult == 1);

    }

}
