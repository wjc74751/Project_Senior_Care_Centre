package StayManagement.dao;

import StayManagement.bean.Stay;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import static StayManagement.util.DruidUtils.getPool;
//by 王骏驰
public class StayDao {
    static QueryRunner queryRunner = new QueryRunner(getPool());
    public static List<Stay> queryByName(String build, String floor, String room, String bed) throws SQLException {
        String sql = "SELECT id,patientName,gender,age,build,floor,room,bed,startDate,endDate FROM stay WHERE build like '%"+build+"%' and floor like '%"+floor+"%' and room like '%"+room+"%' and bed like '%"+bed+"%'";
        return queryRunner.query(sql,new BeanListHandler<Stay>(Stay.class));
    }
    public static List<Stay> queryById(int id) throws SQLException {
        String sql = "SELECT id,patientName,gender,age,bedId,build,floor,room,bed,startDate,endDate FROM stay WHERE id=?";
            return queryRunner.query(sql,new BeanListHandler<Stay>(Stay.class),id);
    }
    public static int exchangeUpdate(int id,int bedId,String build,String floor,String room,String bed) throws SQLException {
        String sql = "UPDATE stay SET bedId=?,build=?,floor=?,room=?,bed=? WHERE id=?";
        return queryRunner.update(sql,bedId,build,floor,room,bed,id);
    }
    public static int insert(int id, String patientName,int age,boolean gender, int bedId, String build, String floor, String room, String bed, Date startDate, Date endDate) throws SQLException {
        String sql = "INSERT INTO stay (id,patientName,gender,age,bedId,build,floor,room,bed,startDate,endDate) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
        return queryRunner.update(sql,id,patientName,gender,age,bedId,build,floor,room,bed,startDate,endDate);
    }

}
//by 王骏驰
//天动万象！！！
