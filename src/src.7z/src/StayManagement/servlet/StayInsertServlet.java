package StayManagement.servlet;

import StayManagement.service.StayService;
import com.alibaba.fastjson.JSONObject;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
//by 王骏驰
@WebServlet("/stay/insert")
public class StayInsertServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=utf-8");
        boolean insertResult = false;
        try {
            insertResult = StayService.stay(Integer.parseInt(req.getParameter("id")), Date.valueOf(req.getParameter("startDate")), Date.valueOf(req.getParameter("endDate")));
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        String JSONString = JSONObject.toJSONString(insertResult ? "患者入住成功！" : "患者入住失败！");
        resp.getWriter().write(JSONString);


    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一
        doGet(req, resp);
    }
}