package StayManagement.servlet;

import StayManagement.service.StayService;
import com.alibaba.fastjson.JSONObject;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
//by 王骏驰
@WebServlet("/stay/delete")
public class StayCancelServlet extends HttpServlet { //退院

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=utf-8");
        boolean deleteResult = false;
        try {
            deleteResult = StayService.deleteById(Integer.parseInt(req.getParameter("id"))); //获取退院病人的ID
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        String JSONString = JSONObject.toJSONString(deleteResult ?"患者退院成功！":"患者退院失败！");
        resp.getWriter().write(JSONString);



    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一
        doGet(req,resp);
    }

}
