package StayManagement.servlet;

import StayManagement.bean.Stay;
import StayManagement.service.StayService;
import com.alibaba.fastjson.JSONObject;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
//by 王骏驰
@WebServlet("/stay/query")
public class StayQueryServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=utf-8");
        List<Stay> queryResult = new ArrayList<Stay>();
        try {
            if (req.getParameter("bedInput") != null)
            {
                queryResult = StayService.queryByName(req.getParameter("buildInput"),req.getParameter("floorInput"),req.getParameter("roomInput"),req.getParameter("bedInput"));
            }
            else
            {
                if (req.getParameter("roomInput") != null) {
                    queryResult = StayService.queryByName(req.getParameter("buildInput"), req.getParameter("floorInput"), req.getParameter("roomInput"), "");
                }
                else
                {
                    if (req.getParameter("floorInput") != null) {
                        queryResult = StayService.queryByName(req.getParameter("buildInput"), req.getParameter("floorInput"), "", "");
                    }
                    else
                    {
                        if (req.getParameter("buildInput") != null) {
                            queryResult = StayService.queryByName(req.getParameter("buildInput"), "", "", "");
                        }
                        else
                        {
                            queryResult = StayService.queryByName("", "", "", "");
                        }
                    }
                }
            }

        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        String JSONString = JSONObject.toJSONString(queryResult);
        System.out.println("Query : " + req.getParameter("buildInput") + req.getParameter("floorInput") + req.getParameter("roomInput") + req.getParameter("bedInput"));
        resp.getWriter().write(JSONString);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一
        doGet(req,resp);
    }

}
