package StayManagement.bean;

import java.sql.Date;
//by 王骏驰
public class Stay {
    private int id; //病人的ID
    private String patientName;
    private boolean gender;
    private int age;
    private int bedId;
    private String build;
    private String floor;
    private String room;
    private String bed;
    private Date startDate;
    private Date endDate;

    public Stay() { //空构造
    }
    public Stay(int id, String patientName, boolean gender, int age, int bedId, String build, String floor, String room, String bed, Date startDate, Date endDate) { //对Stay进行构造
        this.id = id;
        this.patientName = patientName;
        this.gender = gender;
        this.age = age;
        this.bedId = bedId;
        this.build = build;
        this.floor = floor;
        this.room = room;
        this.bed = bed;
        this.startDate = startDate;
        this.endDate = endDate;
    }
    public void setId(int id) {this.id = id;}
    public void setPatientName(String patientName){this.patientName = patientName;}
    public void setGender(boolean gender){this.gender = gender;}
    public void setAge(int age){this.age = age;}
    public void setBedId(int bedId){this.bedId = bedId;}
    public void setBuild(String build){this.build = build;}
    public void setFloor(String floor){this.floor = floor;}
    public void setRoom(String room){this.room = room;}
    public void setBed(String bed){this.bed = bed;}
    public void setStartDate(Date startDate){this.startDate = startDate;}
    public void setEndDate(Date endDate) {this.endDate = endDate; }


    public int getId() {return id;}
    public String getPatientName() {return patientName;}
    public boolean getGender(){return gender;}
    public int getAge(){return age;}
    public int getBedId(){return bedId; }
    public String getBuild(){return build;}
    public String getFloor(){return floor; }
    public String getRoom(){return room;}
    public String getBed(){return bed;}
    public Date getStartDate() {return startDate;}
    public Date getEndDate() {return endDate;}
}
//by 王骏驰
//"这就是，最后一课了！"