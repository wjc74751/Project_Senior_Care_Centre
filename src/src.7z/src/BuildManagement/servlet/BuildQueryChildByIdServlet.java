package BuildManagement.servlet;

import BuildManagement.bean.BuildStructure;
import BuildManagement.service.BuildService;
import com.alibaba.fastjson.JSONObject;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
//by 王骏驰
@WebServlet("/build/queryById/child")
public class BuildQueryChildByIdServlet extends HttpServlet { //通过ID查询子类信息

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=utf-8");
        List<BuildStructure> queryResult = new ArrayList<>();
        try {
            if (req.getParameter("buildIdInput") != null)
            {
                queryResult = BuildService.getChildById(Integer.parseInt(req.getParameter("buildIdInput")));
            }
            else if (req.getParameter("floorIdInput") != null)
            {
                queryResult = BuildService.getChildById(Integer.parseInt(req.getParameter("floorIdInput")));
            }
            else if (req.getParameter("roomIdInput") != null)
            {
                queryResult = BuildService.getChildById(Integer.parseInt(req.getParameter("roomIdInput")));
            }

        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        String JSONString = JSONObject.toJSONString(queryResult);
        resp.getWriter().write(JSONString);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一
        doGet(req,resp);
    }
}