package BuildManagement.servlet;

import BuildManagement.bean.BuildStructure;
import BuildManagement.service.BuildService;
import com.alibaba.fastjson.JSONObject;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
//by 王骏驰
@WebServlet("/build/queryByName/child")
public class BuildQueryChildByNameServlet extends HttpServlet { //通过buildStructureName查询子类信息

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=utf-8");
        List<BuildStructure> queryResult = new ArrayList<>();
        try {
            if (req.getParameter("buildInput") != null)
            {
                queryResult = BuildService.getChildByName(req.getParameter("buildInput"));
            }
            else if (req.getParameter("floorInput") != null)
            {
                queryResult = BuildService.getChildByName(req.getParameter("floorInput"));
            }
            else if (req.getParameter("roomInput") != null)
            {
                queryResult = BuildService.getChildByName(req.getParameter("roomInput"));
            }

        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        String JSONString = JSONObject.toJSONString(queryResult);
        resp.getWriter().write(JSONString);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //合二为一
        doGet(req,resp);
    }
}
