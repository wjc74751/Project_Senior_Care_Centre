package BuildManagement.service;

import BuildManagement.bean.BuildStructure;
import BuildManagement.dao.BuildDao;

import java.sql.SQLException;
import java.util.List;
//by 王骏驰
public class BuildService {
    public static List<BuildStructure> getAllBuild() throws SQLException {
        return BuildDao.getAllBuild();
    }
    public static List<BuildStructure> getChildByName(String parent) throws SQLException { //通过父级名称获取子级建筑结构信息
        return BuildDao.getChildByName(parent);
    }
    public static List<BuildStructure> getChildById(int parentId) throws SQLException //通过父类ID获取子类信息
    {
        return BuildDao.getChildById(parentId);
    }
    public static boolean insert(String buildStructureName,String buildId,String floorId,String roomId,String bedId,boolean isRareRoom) throws SQLException { //insert build,floor,room,bed
        int insertResult = 0;
        if (buildId == null && floorId == null && roomId == null && bedId == null) //insert build
        {
            insertResult = BuildDao.insert(buildStructureName,"",5,-1);
        }
        else if (buildId != null && floorId == null && roomId == null && bedId == null) //insert floor
        {
            BuildStructure parentBuildStructure = BuildDao.getById(Integer.parseInt(buildId)).get(0); //get parent
            insertResult = BuildDao.insert(buildStructureName,parentBuildStructure.getBuildStructureName(),4,Integer.parseInt(buildId));
        }
        else if(buildId != null && floorId != null && roomId == null && bedId == null) //insert room
        {
            BuildStructure parentBuildStructure = BuildDao.getById(Integer.parseInt(floorId)).get(0); //get parent
            insertResult = BuildDao.insert(buildStructureName,parentBuildStructure.getBuildStructureName(),isRareRoom?3:2,Integer.parseInt(floorId));
        }
        else if(buildId != null && floorId != null && roomId != null && bedId == null) //insert bed
        {
            BuildStructure parentBuildStructure = BuildDao.getById(Integer.parseInt(roomId)).get(0); //get parent
            if (parentBuildStructure.getBuildStructureType() == 2)
            {
                insertResult = BuildDao.insert(buildStructureName,parentBuildStructure.getBuildStructureName(),1,Integer.parseInt(roomId));
            }

        }
        return (insertResult == 1);
    }
    public static boolean deleteById(String buildId,String floorId,String roomId,String bedId) throws SQLException { //通过ID进行删除
        int deleteResult = 0;
        if (buildId != null && floorId != null && roomId == null && bedId == null) //delete floor
        {
            if (BuildDao.getChildById(Integer.parseInt(floorId)) != null && !BuildDao.getChildById(Integer.parseInt(floorId)).isEmpty())
            {
                //有子节点
            }
            else
            {
                deleteResult = BuildDao.deleteById(Integer.parseInt(floorId)); //无子节点
            }

        }
        else if (buildId != null && floorId != null && roomId != null && bedId == null) //delete room
        {
            if (BuildDao.getChildById(Integer.parseInt(roomId)) != null && !BuildDao.getChildById(Integer.parseInt(roomId)).isEmpty())
            {
                //有子节点
            }
            else
            {
                deleteResult = BuildDao.deleteById(Integer.parseInt(roomId)); //无子节点
            }
        }
        else if (buildId != null && floorId != null && roomId != null && bedId != null) //delete bed
        {
            BuildStructure buildStructure = BuildDao.getById(Integer.parseInt(bedId)).get(0);
            if (buildStructure.getIsStay() == false)
            {
                if (BuildDao.getChildById(Integer.parseInt(bedId)) != null && !BuildDao.getChildById(Integer.parseInt(bedId)).isEmpty())
                {
                    //有子节点
                }
                else
                {
                    deleteResult = BuildDao.deleteById(Integer.parseInt(bedId)); //无子节点
                }
            }

        }
        return (deleteResult == 1);
    }



}
