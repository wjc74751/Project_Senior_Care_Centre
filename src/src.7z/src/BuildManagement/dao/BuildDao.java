package BuildManagement.dao;

import BuildManagement.bean.BuildStructure;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.List;
import java.util.Random;

import static StayManagement.util.DruidUtils.getPool;
//by 王骏驰
public class BuildDao {
    static QueryRunner queryRunner = new QueryRunner(getPool());
    public static List<BuildStructure> getAllBuild() throws SQLException {
        String sql = "SELECT * FROM build WHERE buildStructureType=?";
        return queryRunner.query(sql,new BeanListHandler<BuildStructure>(BuildStructure.class),5);
    }
    public static List<BuildStructure> getChildByName(String parent) throws SQLException {
        String sql = "SELECT * FROM build WHERE parent=?";
        return queryRunner.query(sql,new BeanListHandler<BuildStructure>(BuildStructure.class),parent);
    }
    public static List<BuildStructure> getByName(String child) throws SQLException {
        String sql = "SELECT * FROM build WHERE buildStructureName=?";
        return queryRunner.query(sql,new BeanListHandler<BuildStructure>(BuildStructure.class),child);
    }
    public static List<BuildStructure> getNoStayBedId() throws SQLException //查询未入住的床位ID
    {
        String sql = "SELECT bedId FROM build WHERE isStay=0 and buildStructureType=1";
        return queryRunner.query(sql,new BeanListHandler<BuildStructure>(BuildStructure.class));
    }
    public static int stayBed(int bedId) throws SQLException { //设置床位为已入住
        String sql = "UPDATE build SET isStay=1 WHERE bedId=?";
        return queryRunner.update(sql,bedId);
    }
    public static List<BuildStructure> getBedByBedId(int bedId) throws SQLException {
        String sql = "SELECT buildStructureName FROM build WHERE bedId=?";
        return queryRunner.query(sql,new BeanListHandler<BuildStructure>(BuildStructure.class),bedId);
    }
    public static int outStayBed(int bedId) throws SQLException { //设置相应床位为未入住
        String sql = "UPDATE build SET isStay=0 WHERE bedId=?";
        return queryRunner.update(sql,bedId);
    }
    public static int insert(String buildStructureName,String parent,int buildStructureType,int parentId) throws SQLException { //添加相应结构
        Random random = new Random();
        int buildStructureId = random.nextInt(2147483647);
        if (buildStructureType == 1)
        {
            int bedId = random.nextInt(2147483647);
            boolean isStay = false;
            String sql = "INSERT INTO build (buildStructureName,parent,buildStructureType,bedId,isStay,buildStructureId,parentId) VALUES (?,?,?,?,?,?,?)";
            return queryRunner.update(sql,buildStructureName,parent,buildStructureType,bedId,isStay,buildStructureId,parentId);
        }
        else if (buildStructureType == 2 || buildStructureType == 4)
        {
            String sql = "INSERT INTO build (buildStructureName,parent,buildStructureType,buildStructureId,parentId) VALUES (?,?,?,?,?)";
            return queryRunner.update(sql,buildStructureName,parent,buildStructureType,buildStructureId,parentId);
        }
        else if (buildStructureType == 3)
        {
            int rareRoomId = random.nextInt(2147483647);
            String sql = "INSERT INTO build (buildStructureName,parent,buildStructureType,rareRoomId,buildStructureId,parentId) VALUES (?,?,?,?)";
            return queryRunner.update(sql,buildStructureName,parent,buildStructureType,rareRoomId,buildStructureId,parentId);
        }
        else if (buildStructureType == 5)
        {
            String sql = "INSERT INTO build (buildStructureName,buildStructureType,buildStructureId) VALUES (?,?,?)";
            return queryRunner.update(sql,buildStructureName,buildStructureType,buildStructureId);
        }

        return 0;
    }
    public static List<BuildStructure> getById(int buildStructureId) throws SQLException
    {
        String sql = "SELECT * FROM build WHERE buildStructureId=?";
        return queryRunner.query(sql,new BeanListHandler<BuildStructure>(BuildStructure.class),buildStructureId);
    }
    public static List<BuildStructure> getChildById(int parentId) throws SQLException
    {
        String sql = "SELECT * FROM build WHERE parentId=?";
        return queryRunner.query(sql,new BeanListHandler<BuildStructure>(BuildStructure.class),parentId);
    }
    public static int deleteById(int buildStructureId) throws SQLException
    {
        String sql = "DELETE FROM build WHERE buildStructureId=?";
        return queryRunner.update(sql,buildStructureId);
    }

}
