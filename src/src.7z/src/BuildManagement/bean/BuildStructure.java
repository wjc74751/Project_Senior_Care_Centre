package BuildManagement.bean;
//by 王骏驰
public class BuildStructure {
    private String buildStructureName; //本类名称
    private String parent; //父类名称
    //邻接表结构
    private int bedId; //若结构为床，则为床的ID，否则为null
    private int buildStructureType; //1为床位，2为普通房间，3为特殊房间，4为楼层，5为楼体
    private int buildStructureId; //结构ID（唯一的），该变量作为辨识符
    private int parentId; //父类的结构ID（唯一的）
    private boolean isStay; //若结构为床，则为床是否入住，否则为null

    public BuildStructure() { //空构造
    }

    public BuildStructure(String buildStructureName,String parent, int bedId,int buildStructureType,int buildStructureId,int parentId,boolean isStay) { //BuildStructure构造
        this.buildStructureName = buildStructureName;
        this.parent = parent;
        this.bedId = bedId;
        this.buildStructureType = buildStructureType;
        this.buildStructureId = buildStructureId;
        this.parentId = parentId;
        this.isStay = isStay;
    }
    public void setBuildStructureName(String buildStructureName){this.buildStructureName = buildStructureName;}
    public void setParent(String parent) {this.parent = parent;}
    public void setBedId(int bedId) {this.bedId = bedId;}
    public void setBuildStructureType(int buildStructureType) {this.buildStructureType = buildStructureType;}
    public void setBuildStructureId(int buildStructureId) {this.buildStructureId = buildStructureId;}
    public void setParentId(int parentId) {this.parentId = parentId;}
    public void setIsStay(boolean isStay) {this.isStay = isStay;}

    public String getBuildStructureName() {
        return buildStructureName;
    }
    public String getParent() {return parent;}
    public int getBedId() {return bedId;}
    public int getBuildStructureType() {return buildStructureType;}
    public int getBuildStructureId() {return buildStructureId;}
    public int getParentId() {return parentId;}
    public boolean getIsStay() {return isStay;}
}
//by 王骏驰
//魈真的好帅，要不是魈谁工作啊？
